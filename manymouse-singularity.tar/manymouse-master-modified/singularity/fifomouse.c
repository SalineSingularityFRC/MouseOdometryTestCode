 /*
 * A test file for ManyMouse that dumps input data to stdout.
 *
 * Please see the file LICENSE.txt in the source's root directory.
 *
 *  This file written by Ryan C. Gordon
 *
 *  Edited by Michael Wolf, FRC Team 5066 "Singularity"
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "manymouse.h"

//Libraries for FIFO
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

//Other libraries imported by Singularity
#include <time.h>

/*NOTE: Mouse write data as CSV separated by newline characters

   intial output: start

   format:        < Mouse ID, event, param1, amount, timestamp (milliseconds since start) >

     - event: 0 = relative motion, 1 = button press, 2 = no mouse detected, 3 = error initializing manymouse, 100 = startTracking, 101 = endTracking
     - param1: 0 = X, 1 = Y (for rel motion) ; 0 = down, 1 = up (for button press)
     - amount = value associated with the command 
       - distance travelled for relative motion
       - button: id of the button

   final output:  close

*/

int main(int argc, char **argv)
{

    //Initialize string to print out
    char toSend[100]; 

    //Initialize FIFO Variables
    int fd;
    char * myfifo = "/tmp/myfifo";

    //Standard manymouse code
    ManyMouseEvent event;
    const int available_mice = ManyMouse_Init();
    int i;

    printf("Waiting for FIFO reader to connect...");

    //create the FIFO
    mkfifo(myfifo, 0666);
    fd = open(myfifo, O_WRONLY);

    //int numEvents = 0;

    //Modified manymouse code
    if (available_mice < 0)
    {
        write(fd, "3", sizeof("3"));
        ManyMouse_Quit();
        return 2;
    }

        printf("ManyMouse driver: %s\n", ManyMouse_DriverName());

    if (available_mice == 0)
    {
        sprintf(toSend, "2\n");
        write(fd, toSend, sizeof(toSend));
        ManyMouse_Quit();
        return 1;
    }

    for (i = 0; i < available_mice; i++)
        printf("#%d: %s\n", i, ManyMouse_DeviceName(i));
    printf("\n");

    write(fd, "100\n", sizeof("100\n"));

    clock_t prevTime = clock();
    clock_t currentTime = clock();
    clock_t diff = clock();

    int count;

    //Should I calculate the timestamp before each print of in the while(1) loop?
    while (1)
    {
        //write(fd, "between", sizeof("between"));
	///printf("%ld",clock() * 100000 / CLOCKS_PER_SEC);

	count = 0;

        while (ManyMouse_PollEvent(&event))
        {
	    if(count == 0) {

		currentTime = clock();
		diff = currentTime - prevTime;
		prevTime = currentTime;

            }
            //write(fd,"something",sizeof("something"));

            if (event.type == MANYMOUSE_EVENT_RELMOTION)
            {
                currentTime = clock();
                sprintf(toSend, "%u,0,%s,%d,%ld", event.device,
                        event.item == 0 ? "X" : "Y", event.value, diff * 1000 / CLOCKS_PER_SEC);
                write(fd, toSend, sizeof(toSend));
                //start = clock();
            }

            else if (event.type == MANYMOUSE_EVENT_ABSMOTION)
            {
                
                sprintf(toSend, "%u,2,%s,%d,%ld", event.device,
                        event.item == 0 ? "X" : "Y", event.value, diff * 1000 / CLOCKS_PER_SEC);
                write(fd, toSend, sizeof(toSend));
                
                //write(fd, "absMotion", sizeof("absMotion"));
            }

            else if (event.type == MANYMOUSE_EVENT_BUTTON)
            {
                sprintf(toSend, "%u,1,%s,%u,%ld", event.device, event.value ? "down" : "up",
                        event.item, diff * 1000 / CLOCKS_PER_SEC);
                write(fd, toSend, sizeof(toSend));
            }

            else if (event.type == MANYMOUSE_EVENT_SCROLL)
            {
                const char *wheel;
                const char *direction;
                if (event.item == 0)
                {
                    wheel = "vertical";
                    direction = ((event.value > 0) ? "up" : "down");
                }
                else
                {
                    wheel = "horizontal";
                    direction = ((event.value > 0) ? "right" : "left");
                }
                printf("Mouse #%u wheel %s %s\n", event.device,
                        wheel, direction);
            }

            else if (event.type == MANYMOUSE_EVENT_DISCONNECT)
                printf("Mouse #%u disconnect\n", event.device);

            else
            {
                printf("Mouse #%u unhandled event type %d\n", event.device,
                        event.type);
            }

	    count++;
        }

    }

    //Close and unlink FIFO, then quit manymouse
    close(fd);
    unlink(myfifo);
    ManyMouse_Quit();
    return 0;
}

/* end of test_manymouse_stdio.c ... */

